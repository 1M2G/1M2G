Question1
(a) A list is being used to store the numbers because it is easy to order,change and allow duplication of values.
(b)This initialization ensures that the maximum sum will always be at least as large as the first element of the list. This is because if all other elements in the list are negative, then maxSum will be equal to the first element of the list, which is greater than zero and this will provides a starting point for the maximum sum calculation.
(c)The for loop iterates over each element in the sequence starting with the first element at index 0 and executes the block of code inside the loop for each element and the purpose of the sumz variable is to add elements in the list from index 0 sumultineously.It is being updated by the length of the list "lst".
(d)If the sumz which is got from adding the elements in the list is greater than the maxSum which is the element in the first index 0, then the maxSum is equal to the sumz. The range in the for loop updates the maxSum variable.
(e)The time complexity of the code is O(n), where n is the length of the input list because the code only iterates through the list once.

The choice of data structure and algorithm contributes to its efficiency or performance because it allows us to find the maximum subarray sum in linear time, which is much faster than other algorithms that have a higher time complexity.
 OBJECTIVES
 1.c)append()
 2.b)my_list.insert(0,'x')
 3.b)[111,7,2,1,4]
 4.a)my_list.copy()
 5.d)my_list.delete(0)
 6.a)Creates a new list l2 with the same content as l1
 7.a)'apple' not in fruits
 8.d)
 9.c)
 10.a)