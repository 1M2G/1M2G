def martyr_count(name: str) -> str:
    catholic_martyrs = ['Achileo Kiwanuka', 'Adolphus Ludigo Mukasa', 'Ambrosius Kibuuka', 'Anatoli Kiriggwajjo', 'Andrew Kaggwa', 'Antanansio Bazzekuketta', 'Bruno Sserunkuuma', 'Charles Lwanga', 'Denis Ssebuggwawo', 'Gonzaga Gonza', 'Gyavira Musoke', 'James Buuzaabalyaawo', 'John Maria Muzeeyi', 'Joseph Mukasa Kizito', 'Lukka Baanabakintu', 'Matiya Mulumba', 'Mbaga Tuzinde', 'Mugagga Lubowa', 'Mukasa Kiriwawanvu', 'Nowa Mawaggali', 'Ponsiano Ngondwe']
    anglican_martyrs = ['Aaron Lubega', 'Apollo Kivebulaya', 'Eria Sebukyala', 'Fredrick Kizza', 'George Kizza', 'James Hannington', 'Janani Luwum', 'Joseph Balikuddembe Kizito', 'Mark Kakumba Matia Mulumba', 'Nuhu Mbegu Robert Munyagayirwa Samwiri Mukasa Yefusa Namayanja Yohana Mukasa Yosefu Lugalama Yowana Kitaka Yowana Maria Mukasa']
    if name in catholic_martyrs:
        return "Catholic"
    elif name in anglican_martyrs:
        return "anglican_martyrs"
    else:
        return 